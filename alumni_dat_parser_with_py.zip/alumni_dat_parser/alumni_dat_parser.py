import os
import sys
from datetime import datetime

## Helpful tip --> Address sometimes contain newline, in excel call clean on whole file first to remove newline
#        ## Key == firtname_lastname_initYR_initMNTH_initDAY
#        init_date = datetime.strptime(dat[6], '%m/%d/%Y')
#        key = dat[0].lower() + '_' + dat[2].lower() + '_' + init_date.strftime("%Y_%m_%d")

class alumni_dat:

    def __init__(self, headers):
        # Initialize Baseline Alumni Data
        self.base_headers           = headers
        self.was_mn_base            = False
        self.was_mn_beta_almn       = False
        self.was_mn_gam_delt_almn   = False
        self.was_tc_almn            = False
        self.base_info              = { }
        for h in self.base_headers:
            self.base_info[h] = 'NA'

    def base_key(self):
        return self.base_info['salesforce_id']

    def assimilate(self, new_one):
        for key, val in self.base_info.items():
            ## If we had an NA before and now we have value, add it
            if(val == 'NA' and new_one.base_info[key] != 'NA'):
                self.base_info[key] = new_one.base_info[key]

            ## If both were not NA and both were unequal, send error
            elif(val != 'NA' and new_one.base_info[key] != 'NA' and val != new_one.base_info[key]):
                print('ERROR: Unexpected mismatch during assimilation\n[%s] --> [%s] != [%s]' % (key, val, new_one.base_info[key]))

            self.was_mn_base        = True if(new_one.was_mn_base)      else self.was_mn_base
            self.was_mn_beta_almn   = True if(new_one.was_mn_beta_almn) else self.was_mn_beta_almn
            self.was_tc_almn        = True if(new_one.was_tc_almn)      else self.was_tc_almn


## Global Paths
# region 

## Global Foundation Data Paths
mn_beta_all_time    = r'.\raw_inputs\from_foundation\2022\mn_beta_all_time_member_list.csv'
mn_beta_alumni      = r'.\raw_inputs\from_foundation\2022\mn_beta_alumni_list.csv'
mn_gam_delt_alumni  = r'.\raw_inputs\from_foundation\2022\mn_gamma_mn_delta_2022.csv'
twin_cities_alumni  = r'.\raw_inputs\from_foundation\2022\twin_cities_alumni_list.csv'

## Global Pennington Data Paths
penn_feasability    = r'.\raw_inputs\pennington_feasibility\penngington_feasibility_study.csv'
penn_call_status    = r'.\raw_inputs\pennington_feasibility\penngington_feasibility_study.csv'
penn_contact_list   = r'.\raw_inputs\pennington_feasibility\penngington_feasibility_study.csv'
penn_eras           = r'.\raw_inputs\pennington_feasibility\penngington_feasibility_study.csv'
penn_focus_group    = r'.\raw_inputs\pennington_feasibility\penngington_feasibility_study.csv'

## Global Alumni Event Paths
fd_base_path        = r'.\raw_inputs\alumni_event_attendance\founders_day'
fd_attendance       = { 2016: os.path.join(fd_base_path, 'fd_2016.csv'),
                        2017: os.path.join(fd_base_path, 'fd_2017.csv'),
                        2019: os.path.join(fd_base_path, 'fd_2019.csv'),
                        2020: os.path.join(fd_base_path, 'fd_2020.csv'),
                        2022: os.path.join(fd_base_path, 'fd_2022.csv')
                      }
tccup_base_path     = r'.\raw_inputs\alumni_event_attendance\tcaa_cup'
tccup_attendance    = { 2016: os.path.join(tccup_base_path, 'tcaa_2016.csv'),
                        2017: os.path.join(tccup_base_path, 'tcaa_2016.csv'),
                        2019: os.path.join(tccup_base_path, 'tcaa_2016.csv')
                      }

## Global Misc Paths
fb_members          =  r'.\raw_inputs\misc\facebook_list_04_01_22.csv'

#endregion 

## Global Objects
almn_dict = {}

def add_to_header(header_in, file_in):
    with open(file_in, 'r') as f:
        line = f.readline()
        for h in line.split(','):
            h = h.lower().replace(' ', '_').replace('\n', '')
            if(h not in header_in):
                header_in.append(h)

def parse_base_file(file_in, header_in, true_switch=0, error_on_exist=False):
    with open(file_in, 'r') as f:
        local_headers   = { }
        for h in header_in:
            local_headers[h] = -1

        head_split = f.readline().split(',')
        for h in range(0, len(head_split)):
            local_headers[head_split[h].lower().replace(' ', '_').replace('\n', '')] = h

        lines = f.readlines()
        for l in lines:
            tmp     = alumni_dat(header_in)
            values  = l.split(',')
            for name, index in local_headers.items():
                if(index != -1):
                    tmp.base_info[name] = values[index].replace('\n', '').replace('  ', ' ')

            tmp.was_mn_base             = True if(true_switch == 0) else tmp.was_mn_base
            tmp.was_mn_beta_almn        = True if(true_switch == 1) else tmp.was_mn_beta_almn
            tmp.was_mn_gam_delt_almn    = True if(true_switch == 2) else tmp.was_mn_gam_delt_almn
            tmp.was_tc_almn             = True if(true_switch == 3) else tmp.was_tc_almn

            if(tmp.base_key() in almn_dict):
                if(error_on_exist):
                    print("ERROR: Unexpected sales force ID key repeat [%s]" % tmp.base_key())
                else:
                    almn_dict[tmp.base_key()].assimilate(tmp)
            else:
                almn_dict[tmp.base_key()] = tmp


## Parse Baseline Alumni Object
def parse_baseline():

    ## Extract unique list of headers between all three files
    #region
    headers = []
    add_to_header(headers, mn_beta_all_time)
    add_to_header(headers, mn_beta_alumni)
    add_to_header(headers, mn_gam_delt_alumni)
    add_to_header(headers, twin_cities_alumni)
    #endregion

    ## Parse the first alumni dump file
    parse_base_file(mn_beta_all_time,   headers, 0, error_on_exist=True)
    parse_base_file(mn_beta_alumni,     headers, 1, error_on_exist=False)
    parse_base_file(mn_gam_delt_alumni, headers, 2, error_on_exist=False)
    parse_base_file(twin_cities_alumni, headers, 3, error_on_exist=False)

    ## Print some final statistics
    was_mn_base_cnt         = 0
    was_mn_beta_almn_cnt    = 0
    was_tc_almn_cnt         = 0
    mn_base_not_mn_almn     = 0
    mn_almn_not_mn_base     = 0
    for key, val in almn_dict.items():
        was_mn_base_cnt         = (was_mn_base_cnt+1)       if val.was_mn_base      else was_mn_base_cnt
        was_mn_beta_almn_cnt    = (was_mn_beta_almn_cnt+1)  if val.was_mn_beta_almn else was_mn_beta_almn_cnt
        was_tc_almn_cnt         = (was_tc_almn_cnt+1)       if val.was_tc_almn      else was_tc_almn_cnt

        mn_base_not_mn_almn = (mn_base_not_mn_almn+1) if (val.was_mn_base and not val.was_mn_beta_almn) else mn_base_not_mn_almn
        mn_almn_not_mn_base = (mn_almn_not_mn_base+1) if (val.was_mn_beta_almn and not val.was_mn_base) else mn_almn_not_mn_base

    print('TOTAL Alumni:                    [%4d]' % len(almn_dict))
    print('MN Beta All Time Alumni Count:   [%4d]' % was_mn_base_cnt)
    print('MN Beta Alumni Count:            [%4d]' % was_mn_beta_almn_cnt)
    print('TC Alumni Count:                 [%4d]' % was_tc_almn_cnt)
    print('MN Base, Not MN Alum:            [%4d]' % mn_base_not_mn_almn)
    print('MN Alum, Not MN Base:            [%4d]' % mn_almn_not_mn_base)
            
def main():
    print("Starting Alumni Parse")

    parse_baseline()

if __name__ == "__main__":
    main()
     